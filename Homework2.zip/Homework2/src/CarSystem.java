import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
class Car {
    int id;
    String make;
    String model;
    int yearOfManufacture;
    String color;
    double price;
    String registrationNumber;

    // Constructor
    public Car(int id, String make, String model, int yearOfManufacture, String color, double price, String registrationNumber) {
        this.id = id;
        this.make = make;
        this.model = model;
        this.yearOfManufacture = yearOfManufacture;
        this.color = color;
        this.price = price;
        this.registrationNumber = registrationNumber;
    }
    //Using ToString method for easy printing
    @Override
    public String toString() {
        return id + ", " + make + ", " + model + ", " + yearOfManufacture + ", " + color + ", " + price + ", " + registrationNumber;
    }
}

public class CarSystem {
    public static void main(String[] args) throws IOException {
        // Array of car objects 
        List<Car> cars = new ArrayList<>();
        cars.add(new Car(1, "Toyota", "Corolla", 2015, "Blue", 15000, "ABC123"));
        cars.add(new Car(2, "Ford", "Mustang", 2018, "Red", 30000, "XYZ987"));
        cars.add(new Car(4, "Toyota", "Camry", 2017, "Gray", 18000, "DEF789"));
        cars.add(new Car(5, "Ford", "Fusion", 2012, "Black", 12000, "UVW345"));
        cars.add(new Car(7, "Audi", "A4", 2016, "Black", 22000, "JKL222"));
        cars.add(new Car(10, "Ford", "Explorer", 2015, "Gray", 25000, "STU555"));

        // Save to files based on different criteria
        saveCarsByMake(cars, "Ford");
        saveCarsByMake(cars, "Toyota");
        saveCarsByMake(cars, "Audi");
        saveCarsByModelAndUsage(cars, "Corolla", 5); // Cars used for more than 5 years
        saveCarsByModelAndUsage(cars, "Fusion", 5); // Cars used for more than 5 years
        saveCarsByYearAndPrice(cars, 2015, 12000); // Cars from 2015 with price > 12000
    }

    // Save list of cars by make to a file
    public static void saveCarsByMake(List<Car> cars, String make) throws IOException {
        FileWriter writer = new FileWriter(make + "_cars.txt");
        for (Car car : cars) {
            if (car.make.equalsIgnoreCase(make)) {
                writer.write(car.toString() + "\n");
            }
        }
        writer.close();
        System.out.println("Cars of make " + make + " saved to file.");
    }

    // Save list of cars by model and usage (in years) to a file
    public static void saveCarsByModelAndUsage(List<Car> cars, String model, int n) throws IOException {
        int currentYear = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR);
        FileWriter writer = new FileWriter(model + "_used_more_than_" + n + "_years.txt");
        for (Car car : cars) {
            int yearsInUse = currentYear - car.yearOfManufacture;
            if (car.model.equalsIgnoreCase(model) && yearsInUse > n) {
                writer.write(car.toString() + "\n");
            }
        }
        writer.close();
        System.out.println("Cars of model " + model + " used for more than " + n + " years saved to file.");
    }

    // Save list of cars by year of manufacture and price to a file
    public static void saveCarsByYearAndPrice(List<Car> cars, int yearOfManufacture, double minPrice) throws IOException {
        FileWriter writer = new FileWriter("cars_from_" + yearOfManufacture + "_price_greater_than_" + minPrice + ".txt");
        for (Car car : cars) {
            if (car.yearOfManufacture == yearOfManufacture && car.price > minPrice) {
                writer.write(car.toString() + "\n");
            }
        }
        writer.close();
        System.out.println("Cars from year " + yearOfManufacture + " with price greater than " + minPrice + " saved to file.");
    }
}
